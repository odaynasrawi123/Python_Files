from hashlib import sha256

# takes a username and returns passHash if found
def getUserPassHash(name):

    # type: (str) -> str
    """
    Function takes a username and returns passHash if found
    :param name:
    :return passHash if found:
    """

    credF = open("./credentials.txt", "r")
    
    while True:
        # Get next line from file
        line = credF.readline()                   # type: str
    
        # if line is empty
        # end of file is reached
        if not line:
            break

        # remove white space then
        # convert to list with
        # username at index 0
        # and passHash at index 1
        user = line.strip().split(' ')            # type: str

        # check if username equal
        if user[0] == name:
            # if found then return the pass hash
            return user[1]
            break
    
    credF.close()

def hashPass(password):
    # type: (str) -> str
    """
    Function that takes a plain password text and returns it's hash
    :param password:
    :return the sha256 hash:
    """
    return sha256(password.encode()).hexdigest()



