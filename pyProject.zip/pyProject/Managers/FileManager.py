import os

def fileExists(filePath):
    # type: (str) -> bool
    """
    Fucntion that return if True if the fileExists
    :param filePath:
    :return True if the fileExists other returns False:
    """
    return os.path.exists(filePath)

def fileReadAccessable(filePath):
    # type: (str) -> bool
    """
    Function that check if we have access to Read from certian file
    :param filePath:
    :return return True if we have access to Read from a file:
    """
    return os.access(filePath, os.R_OK)

def fileWriteAccessable(filePath):

    # type: (str) -> bool
    """
       Function that check if we have access to Write from certian file
       :param filePath:
       :return return True if we have access to Write from a file:
       """
    return os.access(filePath, os.W_OK)

def fileReadWriteAccessable(filePath):
    # type: (str) -> bool
    """
     Function that check if we have access to Write and Read from certian file
     :param filePath:
     :return return True if we have access to Write and Read from a file:
    """
    return os.access(filePath, os.W_OK) and os.access(filePath, os.R_OK)

def fileIsEmpty(filePath):
    # type: (str) -> bool
    """
    Function that check if the file is empty and return true if empty and false if not
    :param filePath:
    :return return True if is empty:
    """
    return os.stat(filePath).st_size == 0

def deleteFile(filePath):
    # type: (str) -> bool
    """
    Function that return true if we have successfully removed the file
    :param filePath:
    :return return True if the file removed:
    """
    os.remove(filePath)
    return not fileExists(filePath)