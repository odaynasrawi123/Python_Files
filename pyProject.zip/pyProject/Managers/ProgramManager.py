from Managers import FileManager

def option1():
    # type: () -> function
    """
    Function that read two file pathes from user then append file1 content to file2
    :return
    """

    # enter paths
    f1Path = input("Enter first file path:")
    f2Path = input("Enter second file path:")
    
    # check existance
    if(not FileManager.fileExists(f1Path)):
        print("First file doesn't exist")
        return
    if(not FileManager.fileExists(f2Path)):
        print("Second file doesn't exist")
        return

    # check accessibility
    if(not FileManager.fileReadAccessable(f1Path)):
        print("Not allowed to read from first file")
        return
    if(not FileManager.fileWriteAccessable(f2Path)):
        print("Not allowed to write to second file")
        return

    # check if first file is empty
    if(FileManager.fileIsEmpty(f1Path)):
        print("First file is empty")
        return

    # open files
    f1 = open(f1Path, 'r')
    f2 = open(f2Path, 'a')

    # append f1 content to f2
    f2.write(f1.read())

    # open f2 this time for read
    f2 = open(f2Path, 'r')

    # print new content
    print("New content:")
    print(f2.read())

    # close files
    f1.close()
    f2.close()


def option2():

    # type: () -> function
    """
     Function that  read file path from user then delete file
     :return
    """
    # enter path
    path = input("Enter file path to delete:")

    # check existance
    if(not FileManager.fileExists(path)):
        print("File doesn't exist")
        return

    if(not FileManager.deleteFile(path)):
        print("Faild to delete file")
        return

    print("File deleted")



def option3():
    # type: () -> function
    """
    Fucntion that swap files content
    :return
    """

    # enter paths
    f1Path = input("Enter first file path:")
    f2Path = input("Enter second file path:")

    # check existance
    if(not FileManager.fileExists(f1Path)):
        print("First file doesn't exist")
        return
    if(not FileManager.fileExists(f2Path)):
        print("Second file doesn't exist")
        return

    # check accessibility
    if(not FileManager.fileReadWriteAccessable(f1Path)):
        print("No read/write access to first file")
        return
    if(not FileManager.fileReadWriteAccessable(f2Path)):
        print("No read/write access to second file")
        return

    # open files
    f1 = open(f1Path, 'r')
    f2 = open(f2Path, 'r')

    f1Content = f1.read()

    # open file1 to write
    f1 = open(f1Path, 'w')

    #replace file1 content
    f1.write(f2.read())

    # open file2 to write
    f2 = open(f2Path, 'w')

    #replace file2 content
    f2.write(f1Content)

    print("Content swapped")

    # close files
    f1.close()
    f2.close()

# remove word from file content
def option4():
    # type: () -> function
    """
    Fucntion that remove word from file content
    :return
    """
    
    # enter path
    path = input("Enter file path:")
    # enter word in small letters
    word = input("Enter word in small letters:")

    # word validation
    if word != word.lower():
        print("Word must be all small letters sorry!")
        return

    # check existance
    if(not FileManager.fileExists(path)):
        print("File doesn't exist")
        return

    # check accessibility
    if(not FileManager.fileReadWriteAccessable(path)):
        print("No read/write access to file")
        return

    f = open(path, 'r')

    # get file content and remove word
    fileContent = f.read()
    fileContent = fileContent.replace(word, '')

    f = open(path, 'w')

    # write new content
    f.write(fileContent)

    print("Content updated")

    f.close()
    